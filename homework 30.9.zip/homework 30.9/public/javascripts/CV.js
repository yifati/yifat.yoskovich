function changetitle() {
    document.getElementById("h1").innerHTML = "Exercise 3 ";
}