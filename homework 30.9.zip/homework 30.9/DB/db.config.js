module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "yifaT204736581",
    DB: "mysql"
};
